package com.you_purchase.backenduser.service;

import org.springframework.stereotype.Service;

@Service
public class CommodityService extends BaseService {
}
